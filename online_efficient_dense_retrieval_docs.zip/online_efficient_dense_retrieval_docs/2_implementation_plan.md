# Implementation Plan

## Guiding Principle
Build the smallest complete version first. Do not start with all ablations. First make one baseline run end to end, then widen the study.

## Execution Order

### Phase 1: Environment and Skeleton
1. Set up project structure, dependencies, and reproducibility utilities.
2. Decide one teacher encoder and one initial dataset slice.
3. Build data loaders and a simple training loop for the symmetric teacher.

### Phase 2: First End-to-End Retrieval Pipeline
1. Train or fine-tune the teacher bi-encoder.
2. Encode the corpus.
3. Build a FAISS Flat index.
4. Run retrieval evaluation on a held-out split.
5. Add logging for retrieval metrics and runtime.

### Phase 3: Online Measurement Infrastructure
1. Fix one machine and one evaluation protocol.
2. Benchmark batch-size-1 query encoding latency.
3. Measure p50 and p95 latency.
4. Record memory footprint and end-to-end online retrieval latency.

### Phase 4: Asymmetric Students
1. Implement query-side truncation to 4 layers.
2. Implement query-side truncation to 2 layers.
3. Keep the document encoder fixed and full-depth.
4. Re-run training and evaluation with minimal change to the rest of the pipeline.

### Phase 5: Internal Architecture Ablations
Run only one ablation family at first.

Recommended order:
1. pooling change
2. projection head change
3. distillation addition

### Phase 6: Distillation Variant
1. Add a lightweight teacher-student objective.
2. Keep the formulation simple.
3. Compare no-distillation versus distillation for the shallowest useful student.

### Phase 7: Optional Transfer and Systems Extensions
1. Evaluate the best-performing student on one BEIR dataset.
2. Add one ANN comparison such as HNSW or IVF only after the encoder comparison is stable.

## Workflow
### First Things to Do
- choose teacher backbone
- choose dataset slice
- define exact metrics and logging format
- create a simple results table template before running experiments

### What to Do Next
- train teacher
- evaluate teacher
- add latency harness
- add 4-layer student
- add 2-layer student
- choose one architectural modification
- add distillation only after the shallow baselines are stable

## What Not to Do Early
- do not start with multiple model families
- do not mix ANN choices with encoder changes immediately
- do not add many datasets before the first clean result exists
- do not optimize every engineering detail before the pipeline works end to end

## Minimal Project Milestones
### Milestone 1
Teacher model works end to end with FAISS and returns retrieval metrics.

### Milestone 2
Latency measurement is stable and repeatable.

### Milestone 3
4-layer and 2-layer asymmetric students are implemented and benchmarked.

### Milestone 4
One architectural or training intervention is added and compared cleanly.

### Milestone 5
A final tradeoff table and one Pareto-style plot are ready.

## Suggested Result Artifacts
- `results/main_table.csv`
- `results/latency_table.csv`
- `figures/pareto_latency_vs_mrr.png`
- `notes/experiment_log.md`

## Risks
- MS MARCO may still be heavy if training is done from scratch
- retrieval metrics can be noisy on small subsets
- latency measurements can be misleading if hardware conditions drift
- too many ablations may weaken the final story

## Mitigations
- start with a manageable subset
- fix evaluation hardware and protocol early
- keep the first study narrow
- record every run in a structured experiment log
